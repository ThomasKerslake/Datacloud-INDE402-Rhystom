let rotateAngle = 0;
let lightValue = 1;
let lightValueAlt = 1;
let socket;
let incomingData = 0;
let interpIncomingData = 0;
let col = 0;



function setup() {
  var canvas = createCanvas(900, 900, WEBGL);
  canvas.class("myCanvas");
    canvas.parent("myContainer");
    socket = io();
    //socket = io.connect('https://iot-network.herokuapp.com:3000');
    socket = io.connect('http://localhost:3000');
    socket.on('ServerToClient', socketEvents);
}



function draw() {
// Base light / background colour
    background(25);
    canvasLight();
    rotateAngle +=1;
// large center sphere
push();
    rotateX(frameCount * 0.01);
    rotateY(frameCount * 0.01);
    rotateZ(frameCount * 0.01);
    noStroke();
    ambientMaterial(255);
    sphere(100, 100);
pop();

// Torus rotate 0.1
push();
rotateX(rotateAngle * 0.01);
rotateY(rotateAngle * 0.01);
rotateZ(rotateAngle);
noStroke();
ambientMaterial(255);
torus(300, 10, 100, 100);
pop();

// Torus rotate 0.2
push();
rotateX(rotateAngle * 0.01);
rotateY(rotateAngle * 0.02);
rotateZ(rotateAngle);
noStroke();
ambientMaterial(255);
torus(300, 10, 100, 100);
pop();

// Torus rotate 0.3
push();
rotateX(rotateAngle * 0.01);
rotateY(rotateAngle * 0.03);
rotateZ(rotateAngle);
noStroke();
ambientMaterial(255);
torus(300, 10, 100, 100);
pop();

// HALF_PI Plane (depth)
push();
translate(0,300);
rotateX(HALF_PI);
fill(40);
noStroke();
plane(900,900);
pop();
}

// The point light function / setup
function canvasLight(){
  lightValue = map(incomingData,0,10000,0,255); // Light value 'map' to incoming data
  pointLight(lightValue, lightValue,lightValue, 0, 0, 900);
  pointLight(lightValue,lightValue,lightValue, 0, 0, 900);
  pointLight(lightValue, lightValue,lightValue, 0, 0, 900);
  pointLight(lightValue,lightValue,lightValue, 0, 0, 900);
}


function socketEvents(data){
  incomingData = data;
  incomingData = map(incomingData, 0, 100, 0, 255);
  console.log(data);
}
